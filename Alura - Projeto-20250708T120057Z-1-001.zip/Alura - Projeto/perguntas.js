criaCartao(
    'Terraria',
    'O que é Terraria',
    'Cave, lute, explore, construa! Nada é impossível neste jogo de aventura cheio de ação . O mundo é a sua tela e o próprio chão é a sua tinta.'
)

criaCartao(
    'Hollow Knight',
    'O que é Hollow Knight',
    'Uma aventura de ação épica por um vasto reino em ruínas de insetos e heróis . Explore cavernas sinuosas, lute contra criaturas contaminadas e faça amizade com insetos bizarros.'
)

criaCartao(
    'Cuphead',
    'O que é uma Cuphead?',
    'Cuphead é um jogo de ação e tiros clássico, com enorme ênfase nas batalhas de chefes. Inspirado nas animações infantis da década de 1930.'
)

criaCartao(
    'Undertale',
    'O que é Undertale',
    'Neste RPG, você controla um humano que cai no subsolo de um mundo de monstros . Agora você precisa encontrar a saída... ou ficará preso para sempre.'
)

criaCartao(
    'Minecrat',
    'O que é Minecraft?',
    'Explore mundos gerados aleatoriamente e construa coisas incríveis, indo desde as casas mais simples até os mais grandiosos castelos.'
)